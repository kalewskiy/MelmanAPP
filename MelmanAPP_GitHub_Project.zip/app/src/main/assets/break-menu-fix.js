(() => {
  "use strict";

  function openDayMenu(date) {
    const actionButton = document.getElementById("dayActionsBtn");
    if (!actionButton) return;

    // Reuse the app's existing date-picker and menu flow so day-off and
    // break handling remain consistent with the toolbar action.
    actionButton.click();

    const dateInput = document.getElementById("dayActionsDate");
    const submitButton = document.getElementById("modalSubmit");
    if (!dateInput || !submitButton) return;

    dateInput.value = date;
    dateInput.dispatchEvent(new Event("input", { bubbles: true }));
    dateInput.dispatchEvent(new Event("change", { bubbles: true }));
    submitButton.click();
  }

  function addDayMenuButton(header) {
    if (header.querySelector(".daymenu-btn")) return;

    const date = header.dataset.daymenu;
    if (!date) return;

    const button = document.createElement("button");
    button.type = "button";
    button.className = "daymenu-btn";
    button.textContent = "⋯";
    button.title = "Перерыв или выходной";
    button.setAttribute("aria-label", `Меню даты ${date}`);
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      openDayMenu(date);
    });
    header.appendChild(button);
  }

  function install() {
    const grid = document.getElementById("scheduleGrid");
    if (!grid) {
      window.setTimeout(install, 50);
      return;
    }

    const addButtons = () => {
      grid
        .querySelectorAll(".dayhead[data-daymenu]")
        .forEach(addDayMenuButton);
    };

    addButtons();
    new MutationObserver(addButtons).observe(grid, {
      childList: true,
      subtree: true,
    });
  }

  install();
})();
