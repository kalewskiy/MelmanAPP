package com.melmanapp.app;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int CONTACTS_REQUEST = 1001;
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private class AndroidBridge {
        @JavascriptInterface public void importContacts() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, CONTACTS_REQUEST);
                } else loadContacts();
            });
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CONTACTS_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) loadContacts();
            else webView.evaluateJavascript("alert('Чтобы импортировать клиентов, разреши приложению доступ к контактам.');", null);
        }
    }

    private void loadContacts() {
        try {
            JSONArray out = new JSONArray();
            Cursor c = getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                    null, null,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC");
            if (c != null) {
                java.util.HashSet<String> seen = new java.util.HashSet<>();
                while (c.moveToNext()) {
                    String name = c.getString(0);
                    String phone = c.getString(1);
                    if (name == null) name = "Без имени";
                    if (phone == null) phone = "";
                    String key = name + "|" + phone.replaceAll("\\D", "");
                    if (seen.add(key)) {
                        JSONObject o = new JSONObject();
                        o.put("name", name); o.put("phone", phone);
                        out.put(o);
                    }
                }
                c.close();
            }
            String js = "window.onContactsImported(" + JSONObject.quote(out.toString()) + ")";
            runOnUiThread(() -> webView.evaluateJavascript(js, null));
        } catch (Exception e) {
            runOnUiThread(() -> webView.evaluateJavascript("alert('Не удалось прочитать контакты.');", null));
        }
    }
}
