const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const vm = require("node:vm");

const fixScript = path.join(
  __dirname,
  "../app/src/main/assets/break-menu-fix.js",
);

function makeHeader(date) {
  const buttons = [];
  return {
    dataset: { daymenu: date },
    buttons,
    querySelector(selector) {
      const className = selector.slice(1);
      return buttons.find((button) => button.className === className) || null;
    },
    appendChild(button) {
      buttons.push(button);
    },
  };
}

test("day header menu opens the existing menu for that date", () => {
  const headers = [makeHeader("2026-10-15")];
  const grid = {
    querySelectorAll() {
      return headers;
    },
  };
  let currentModal = null;
  let selectedMenuDate = null;
  let actionClicks = 0;
  let observer;

  const actionButton = {
    click() {
      actionClicks += 1;
      currentModal = {
        dateInput: {
          value: "",
          dispatchEvent() {},
        },
        submitButton: {
          click() {
            selectedMenuDate = currentModal.dateInput.value;
            currentModal = null;
          },
        },
      };
    },
  };

  const document = {
    getElementById(id) {
      if (id === "scheduleGrid") return grid;
      if (id === "dayActionsBtn") return actionButton;
      if (id === "dayActionsDate") return currentModal?.dateInput || null;
      if (id === "modalSubmit") return currentModal?.submitButton || null;
      return null;
    },
    createElement(tag) {
      assert.equal(tag, "button");
      const listeners = {};
      return {
        listeners,
        attributes: {},
        addEventListener(type, listener) {
          listeners[type] = listener;
        },
        setAttribute(name, value) {
          this.attributes[name] = value;
        },
      };
    },
  };

  class TestMutationObserver {
    constructor(callback) {
      this.callback = callback;
      observer = this;
    }
    observe() {}
  }

  vm.runInNewContext(fs.readFileSync(fixScript, "utf8"), {
    document,
    Event: class TestEvent {},
    MutationObserver: TestMutationObserver,
    window: { setTimeout() {} },
  });

  const [button] = headers[0].buttons;
  assert.ok(button);
  assert.equal(button.type, "button");
  assert.equal(button.textContent, "⋯");
  assert.equal(button.attributes["aria-label"], "Меню даты 2026-10-15");

  button.listeners.click({
    preventDefault() {},
    stopPropagation() {},
  });

  assert.equal(actionClicks, 1);
  assert.equal(selectedMenuDate, "2026-10-15");

  const nextDay = makeHeader("2026-10-16");
  headers.push(nextDay);
  observer.callback();
  assert.equal(nextDay.buttons.length, 1);
});
